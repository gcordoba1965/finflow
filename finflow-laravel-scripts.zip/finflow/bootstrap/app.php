<?php

use App\Http\Middleware\EnsureAccountActive;
use App\Http\Middleware\EnsureAdmin;
use App\Http\Middleware\EnsureMfaVerified;
use App\Http\Middleware\LogActivity;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'admin'         => EnsureAdmin::class,
            'ensure.mfa'    => EnsureMfaVerified::class,
            'ensure.active' => EnsureAccountActive::class,
        ]);
        $middleware->appendToGroup('web', LogActivity::class);
    })
    ->withExceptions(function (Exceptions $exceptions) {})
    ->create();
