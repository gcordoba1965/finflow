<?php
// config/fortify.php  (key sections)

return [

    'guard'     => 'web',
    'passwords' => 'users',

    /*
    |--------------------------------------------------------------
    | Features enabled
    |--------------------------------------------------------------
    */
    'features' => [
        \Laravel\Fortify\Features::registration(),
        \Laravel\Fortify\Features::resetPasswords(),
        \Laravel\Fortify\Features::emailVerification(),
        \Laravel\Fortify\Features::updateProfileInformation(),
        \Laravel\Fortify\Features::updatePasswords(),
        \Laravel\Fortify\Features::twoFactorAuthentication([
            'confirm'        => true,
            'confirmPassword'=> true,
            'window'         => 1,          // ±1 TOTP period tolerance
        ]),
    ],

    'limiters' => [
        'login'       => 'login',           // 5 attempts / minute
        'two-factor'  => 'two-factor',      // 3 attempts before lockout
    ],

    'views'     => true,
    'home'      => '/',
    'prefix'    => '',

];


// ─────────────────────────────────────────────────────────────
// app/Providers/AppServiceProvider.php
// ─────────────────────────────────────────────────────────────

namespace App\Providers;

use App\Models\IncomeSource;
use App\Models\SavingsGoal;
use App\Models\Transaction;
use App\Policies\IncomeSourcePolicy;
use App\Policies\SavingsGoalPolicy;
use App\Policies\TransactionPolicy;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        // ── Policies ──────────────────────────────────────────
        Gate::policy(Transaction::class,  TransactionPolicy::class);
        Gate::policy(IncomeSource::class, IncomeSourcePolicy::class);
        Gate::policy(SavingsGoal::class,  SavingsGoalPolicy::class);

        // ── Admin gate ────────────────────────────────────────
        Gate::define('admin', fn ($user) => $user->isAdmin());

        // ── Rate limiters ─────────────────────────────────────
        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(5)
                ->by($request->input('email') . '|' . $request->ip());
        });

        RateLimiter::for('two-factor', function (Request $request) {
            return Limit::perMinute(3)
                ->by($request->session()->get('login.id'));
        });

        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(120)
                ->by($request->user()?->id ?: $request->ip());
        });
    }
}


// ─────────────────────────────────────────────────────────────
// bootstrap/app.php  — middleware aliases
// ─────────────────────────────────────────────────────────────

use App\Http\Middleware\EnsureAccountActive;
use App\Http\Middleware\EnsureAdmin;
use App\Http\Middleware\EnsureMfaVerified;
use App\Http\Middleware\LogActivity;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'admin'        => EnsureAdmin::class,
            'ensure.mfa'   => EnsureMfaVerified::class,
            'ensure.active'=> EnsureAccountActive::class,
        ]);
        $middleware->appendToGroup('web', LogActivity::class);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })
    ->create();
